# swagger_client.TokenApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_all_token_ids**](TokenApi.md#get_all_token_ids) | **GET** /nft/{address} | Retrieves the unique NFTs inside a given contract
[**get_contract_nft_transfers**](TokenApi.md#get_contract_nft_transfers) | **GET** /nft/{address}/transfers | Gets NFT transfers of a given contract
[**get_nft_lowest_price**](TokenApi.md#get_nft_lowest_price) | **GET** /nft/{address}/lowestprice | Get the lowest price found for a nft token contract
[**get_nft_metadata**](TokenApi.md#get_nft_metadata) | **GET** /nft/{address}/metadata | Gets the global metadata for a given contract
[**get_nft_owners**](TokenApi.md#get_nft_owners) | **GET** /nft/{address}/owners | Gets the owners of the NFTs of a given contract
[**get_nft_trades**](TokenApi.md#get_nft_trades) | **GET** /nft/{address}/trades | Get nft trades by marketplaces
[**get_nft_transfers_from_to_block**](TokenApi.md#get_nft_transfers_from_to_block) | **GET** /nft/transfers | Gets NFT transfers from a block number to a block number
[**get_token_address_transfers**](TokenApi.md#get_token_address_transfers) | **GET** /erc20/{address}/transfers | Gets erc20 transactions of a token contract
[**get_token_allowance**](TokenApi.md#get_token_allowance) | **GET** /erc20/{address}/allowance | Gets the amount which the spender is allowed to withdraw from the owner.
[**get_token_id_metadata**](TokenApi.md#get_token_id_metadata) | **GET** /nft/{address}/{token_id} | Gets the NFT with the given id of a given contract
[**get_token_id_owners**](TokenApi.md#get_token_id_owners) | **GET** /nft/{address}/{token_id}/owners | Gets the owners of NFTs for a given contract
[**get_token_metadata**](TokenApi.md#get_token_metadata) | **GET** /erc20/metadata | Gets token metadata
[**get_token_metadata_by_symbol**](TokenApi.md#get_token_metadata_by_symbol) | **GET** /erc20/metadata/symbols | Gets token metadata
[**get_token_price**](TokenApi.md#get_token_price) | **GET** /erc20/{address}/price | Gets token price
[**get_wallet_token_id_transfers**](TokenApi.md#get_wallet_token_id_transfers) | **GET** /nft/{address}/{token_id}/transfers | Gets NFT transfers of a given contract
[**re_sync_metadata**](TokenApi.md#re_sync_metadata) | **GET** /nft/{address}/{token_id}/metadata/resync | resync the metadata for a given token_id
[**search_nf_ts**](TokenApi.md#search_nf_ts) | **GET** /nft/search | Retrieves the NFT data based on a metadata search
[**sync_nft_contract**](TokenApi.md#sync_nft_contract) | **PUT** /nft/{address}/sync | Sync a Contract for NFT Index

# **get_all_token_ids**
> NftCollection get_all_token_ids(address, chain=chain, format=format, limit=limit, cursor=cursor)

Retrieves the unique NFTs inside a given contract

Gets data, including metadata (where available), for all token ids for the given contract address. * Results are limited to 500 per page by default * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Retrieves the unique NFTs inside a given contract
    api_response = api_instance.get_all_token_ids(address, chain=chain, format=format, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_all_token_ids: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftCollection**](NftCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_contract_nft_transfers**
> NftTransferCollection get_contract_nft_transfers(address, chain=chain, format=format, limit=limit, cursor=cursor)

Gets NFT transfers of a given contract

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets NFT transfers of a given contract
    api_response = api_instance.get_contract_nft_transfers(address, chain=chain, format=format, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_contract_nft_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_lowest_price**
> Trade get_nft_lowest_price(address, chain=chain, days=days, provider_url=provider_url, marketplace=marketplace)

Get the lowest price found for a nft token contract

Get the lowest price found for a nft token contract for the last x days (only trades paid in ETH)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
days = 56 # int | The number of days to look back to find the lowest price If not provided 7 days will be the default  (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
marketplace = 'opensea' # str | marketplace from where to get the trades (only opensea is supported at the moment) (optional) (default to opensea)

try:
    # Get the lowest price found for a nft token contract
    api_response = api_instance.get_nft_lowest_price(address, chain=chain, days=days, provider_url=provider_url, marketplace=marketplace)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_lowest_price: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **days** | **int**| The number of days to look back to find the lowest price If not provided 7 days will be the default  | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **marketplace** | **str**| marketplace from where to get the trades (only opensea is supported at the moment) | [optional] [default to opensea]

### Return type

[**Trade**](Trade.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_metadata**
> NftContractMetadata get_nft_metadata(address, chain=chain)

Gets the global metadata for a given contract

Gets the contract level metadata (name, symbol, base token uri) for the given contract * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)

try:
    # Gets the global metadata for a given contract
    api_response = api_instance.get_nft_metadata(address, chain=chain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 

### Return type

[**NftContractMetadata**](NftContractMetadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_owners**
> NftOwnerCollection get_nft_owners(address, chain=chain, format=format, limit=limit, cursor=cursor)

Gets the owners of the NFTs of a given contract

Gets all owners of NFT items within a given contract collection * Use after /nft/contract/{token_address} to find out who owns each token id in a collection * Make sure to include a sort parm on a column like block_number_minted for consistent pagination results * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets the owners of the NFTs of a given contract
    api_response = api_instance.get_nft_owners(address, chain=chain, format=format, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_owners: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_trades**
> TradeCollection get_nft_trades(address, chain=chain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, provider_url=provider_url, marketplace=marketplace, offset=offset, limit=limit)

Get nft trades by marketplaces

Get the nft trades for a given contracts and marketplace

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
from_block = 56 # int | The minimum block number from where to get the transfers * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 'to_block_example' # str | To get the reserves at this block number (optional)
from_date = 'from_date_example' # str | The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get the reserves to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
marketplace = 'opensea' # str | marketplace from where to get the trades (only opensea is supported at the moment) (optional) (default to opensea)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Get nft trades by marketplaces
    api_response = api_instance.get_nft_trades(address, chain=chain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, provider_url=provider_url, marketplace=marketplace, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_trades: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **from_block** | **int**| The minimum block number from where to get the transfers * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **str**| To get the reserves at this block number | [optional] 
 **from_date** | **str**| The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get the reserves to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **marketplace** | **str**| marketplace from where to get the trades (only opensea is supported at the moment) | [optional] [default to opensea]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**TradeCollection**](TradeCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_transfers_from_to_block**
> NftTransferCollection get_nft_transfers_from_to_block(chain=chain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, format=format, limit=limit, cursor=cursor)

Gets NFT transfers from a block number to a block number

Gets the transfers of the tokens from a block number to a block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
from_block = 56 # int | The minimum block number from where to get the transfers * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to get the transfers. * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get transfers up until this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets NFT transfers from a block number to a block number
    api_response = api_instance.get_nft_transfers_from_to_block(chain=chain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, format=format, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_nft_transfers_from_to_block: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **from_block** | **int**| The minimum block number from where to get the transfers * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to get the transfers. * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get transfers up until this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_address_transfers**
> Erc20TransactionCollection get_token_address_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)

Gets erc20 transactions of a token contract

Gets ERC20 token contract transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
from_block = 56 # int | The minimum block number from where to get the transfers * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to get the transfers. * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get the transfers to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets erc20 transactions of a token contract
    api_response = api_instance.get_token_address_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_address_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **from_block** | **int**| The minimum block number from where to get the transfers * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to get the transfers. * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to get the transfers (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get the transfers to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**Erc20TransactionCollection**](Erc20TransactionCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_allowance**
> Erc20Allowance get_token_allowance(address, owner_address, spender_address, chain=chain, provider_url=provider_url)

Gets the amount which the spender is allowed to withdraw from the owner.

Gets the amount which the spender is allowed to withdraw from the spender

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
owner_address = 'owner_address_example' # str | The address of the token owner
spender_address = 'spender_address_example' # str | The address of the token spender
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets the amount which the spender is allowed to withdraw from the owner.
    api_response = api_instance.get_token_allowance(address, owner_address, spender_address, chain=chain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_allowance: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **owner_address** | **str**| The address of the token owner | 
 **spender_address** | **str**| The address of the token spender | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**Erc20Allowance**](Erc20Allowance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_id_metadata**
> Nft get_token_id_metadata(address, token_id, chain=chain, format=format)

Gets the NFT with the given id of a given contract

Gets data, including metadata (where available), for the given token id of the given contract address. * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)

try:
    # Gets the NFT with the given id of a given contract
    api_response = api_instance.get_token_id_metadata(address, token_id, chain=chain, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_id_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]

### Return type

[**Nft**](Nft.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_id_owners**
> NftOwnerCollection get_token_id_owners(address, token_id, chain=chain, format=format, limit=limit, cursor=cursor)

Gets the owners of NFTs for a given contract

Gets all owners of NFT items within a given contract collection * Use after /nft/contract/{token_address} to find out who owns each token id in a collection * Make sure to include a sort parm on a column like block_number_minted for consistent pagination results * Requests for contract addresses not yet indexed will automatically start the indexing process for that NFT collection 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets the owners of NFTs for a given contract
    api_response = api_instance.get_token_id_owners(address, token_id, chain=chain, format=format, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_id_owners: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_metadata**
> list[Erc20Metadata] get_token_metadata(addresses, chain=chain, subdomain=subdomain, provider_url=provider_url)

Gets token metadata

Returns metadata (name, symbol, decimals, logo) for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
addresses = ['addresses_example'] # list[str] | The addresses to get metadata for
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets token metadata
    api_response = api_instance.get_token_metadata(addresses, chain=chain, subdomain=subdomain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **addresses** | [**list[str]**](str.md)| The addresses to get metadata for | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**list[Erc20Metadata]**](Erc20Metadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_metadata_by_symbol**
> list[Erc20Metadata] get_token_metadata_by_symbol(symbols, chain=chain, subdomain=subdomain)

Gets token metadata

Returns metadata (name, symbol, decimals, logo) for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
symbols = ['symbols_example'] # list[str] | The symbols to get metadata for
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)

try:
    # Gets token metadata
    api_response = api_instance.get_token_metadata_by_symbol(symbols, chain=chain, subdomain=subdomain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_metadata_by_symbol: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbols** | [**list[str]**](str.md)| The symbols to get metadata for | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 

### Return type

[**list[Erc20Metadata]**](Erc20Metadata.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_price**
> Erc20Price get_token_price(address, chain=chain, provider_url=provider_url, exchange=exchange, to_block=to_block)

Gets token price

Returns the price nominated in the native token and usd for a given token contract address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address of the token contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
exchange = 'exchange_example' # str | The factory name or address of the token exchange (optional)
to_block = 56 # int | to_block (optional)

try:
    # Gets token price
    api_response = api_instance.get_token_price(address, chain=chain, provider_url=provider_url, exchange=exchange, to_block=to_block)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_token_price: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address of the token contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **exchange** | **str**| The factory name or address of the token exchange | [optional] 
 **to_block** | **int**| to_block | [optional] 

### Return type

[**Erc20Price**](Erc20Price.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_wallet_token_id_transfers**
> NftTransferCollection get_wallet_token_id_transfers(address, token_id, chain=chain, format=format, limit=limit, order=order, cursor=cursor)

Gets NFT transfers of a given contract

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
order = 'order_example' # str | The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \"block_number\", \"block_number.ASC\", \"block_number.DESC\", Example 2: \"block_number and contract_type\", \"block_number.ASC,contract_type.DESC\" (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets NFT transfers of a given contract
    api_response = api_instance.get_wallet_token_id_transfers(address, token_id, chain=chain, format=format, limit=limit, order=order, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->get_wallet_token_id_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **order** | **str**| The field(s) to order on and if it should be ordered in ascending or descending order. Specified by: fieldName1.order,fieldName2.order. Example 1: \&quot;block_number\&quot;, \&quot;block_number.ASC\&quot;, \&quot;block_number.DESC\&quot;, Example 2: \&quot;block_number and contract_type\&quot;, \&quot;block_number.ASC,contract_type.DESC\&quot; | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **re_sync_metadata**
> MetadataResync re_sync_metadata(address, token_id, chain=chain, flag=flag, mode=mode)

resync the metadata for a given token_id

ReSync the metadata for an NFT * The metadata(default) flag will request a the NFT's metadata from the already existing token_uri * The uri flag will fetch the latest token_uri from the given NFT address. In sync mode the metadata will also be fetched * The sync mode will make the endpoint synchronous so it will wait for the task to be completed before responding * The async mode(default) will make the endpoint asynchronous so we will wait for the task to be completed before responding 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
token_id = 'token_id_example' # str | The id of the token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
flag = 'metadata' # str | The type of resync to operate (optional) (default to metadata)
mode = 'async' # str | To define the behaviour of the endpoint (optional) (default to async)

try:
    # resync the metadata for a given token_id
    api_response = api_instance.re_sync_metadata(address, token_id, chain=chain, flag=flag, mode=mode)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->re_sync_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **token_id** | **str**| The id of the token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **flag** | **str**| The type of resync to operate | [optional] [default to metadata]
 **mode** | **str**| To define the behaviour of the endpoint | [optional] [default to async]

### Return type

[**MetadataResync**](MetadataResync.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_nf_ts**
> NftMetadataCollection search_nf_ts(q, chain=chain, format=format, filter=filter, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)

Retrieves the NFT data based on a metadata search

Gets NFTs that match a given metadata search.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
q = 'q_example' # str | The search string
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
filter = 'global' # str | What fields the search should match on. To look into the entire metadata set the value to 'global'. To have a better response time you can look into a specific field like name (optional) (default to global)
from_block = 56 # int | The minimum block number from where to start the search * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to end the search * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to start the search (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get search results up until this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Retrieves the NFT data based on a metadata search
    api_response = api_instance.search_nf_ts(q, chain=chain, format=format, filter=filter, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokenApi->search_nf_ts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **str**| The search string | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **filter** | **str**| What fields the search should match on. To look into the entire metadata set the value to &#x27;global&#x27;. To have a better response time you can look into a specific field like name | [optional] [default to global]
 **from_block** | **int**| The minimum block number from where to start the search * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to end the search * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to start the search (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get search results up until this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**NftMetadataCollection**](NftMetadataCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sync_nft_contract**
> sync_nft_contract(address, chain=chain)

Sync a Contract for NFT Index

Sync a Contract for NFT Index 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokenApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)

try:
    # Sync a Contract for NFT Index
    api_instance.sync_nft_contract(address, chain=chain)
except ApiException as e:
    print("Exception when calling TokenApi->sync_nft_contract: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

