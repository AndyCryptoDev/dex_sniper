# RunContractDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abi** | **object** | The contract abi | 
**params** | **object** | The params for the given function | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

