# swagger_client.DefiApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_pair_address**](DefiApi.md#get_pair_address) | **GET** /{token0_address}/{token1_address}/pairAddress | Get pair address based on token0 and token1 address
[**get_pair_reserves**](DefiApi.md#get_pair_reserves) | **GET** /{pair_address}/reserves | Get liquidity pair reserves for an Uniswap V2 based Exchange.

# **get_pair_address**
> ReservesCollection get_pair_address(exchange, token0_address, token1_address, chain=chain, to_block=to_block, to_date=to_date)

Get pair address based on token0 and token1 address

Fetches and returns pair data of the provided token0+token1 combination. The token0 and token1 options are interchangable (ie. there is no different outcome in \"token0=WETH and token1=USDT\" or \"token0=USDT and token1=WETH\") 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.DefiApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | The factory name or address of the token exchange
token0_address = 'token0_address_example' # str | Token0 address
token1_address = 'token1_address_example' # str | Token1 address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
to_block = 'to_block_example' # str | To get the reserves at this block number (optional)
to_date = 'to_date_example' # str | Get the reserves to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)

try:
    # Get pair address based on token0 and token1 address
    api_response = api_instance.get_pair_address(exchange, token0_address, token1_address, chain=chain, to_block=to_block, to_date=to_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefiApi->get_pair_address: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| The factory name or address of the token exchange | 
 **token0_address** | **str**| Token0 address | 
 **token1_address** | **str**| Token1 address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **to_block** | **str**| To get the reserves at this block number | [optional] 
 **to_date** | **str**| Get the reserves to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 

### Return type

[**ReservesCollection**](ReservesCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pair_reserves**
> ReservesCollection get_pair_reserves(pair_address, chain=chain, to_block=to_block, to_date=to_date, provider_url=provider_url)

Get liquidity pair reserves for an Uniswap V2 based Exchange.

Get the liquidity reserves for a given pair address. Only Uniswap V2 based exchanges supported at the moment.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.DefiApi(swagger_client.ApiClient(configuration))
pair_address = 'pair_address_example' # str | Liquidity pair address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
to_block = 'to_block_example' # str | To get the reserves at this block number (optional)
to_date = 'to_date_example' # str | Get the reserves to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Get liquidity pair reserves for an Uniswap V2 based Exchange.
    api_response = api_instance.get_pair_reserves(pair_address, chain=chain, to_block=to_block, to_date=to_date, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefiApi->get_pair_reserves: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pair_address** | **str**| Liquidity pair address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **to_block** | **str**| To get the reserves at this block number | [optional] 
 **to_date** | **str**| Get the reserves to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**ReservesCollection**](ReservesCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

