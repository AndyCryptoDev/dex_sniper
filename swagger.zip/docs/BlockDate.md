# BlockDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_date** | **str** | The date of the block | 
**block** | **float** | The blocknumber | 
**timestamp** | **float** | The timestamp of the block | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

