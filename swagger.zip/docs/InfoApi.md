# swagger_client.InfoApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**endpoint_weights**](InfoApi.md#endpoint_weights) | **GET** /info/endpointWeights | Returns the endpoint price list for rate limits and costs
[**web3_api_version**](InfoApi.md#web3_api_version) | **GET** /web3/version | Returns the web3 api version

# **endpoint_weights**
> list[EndpointWeights] endpoint_weights()

Returns the endpoint price list for rate limits and costs

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.InfoApi(swagger_client.ApiClient(configuration))

try:
    # Returns the endpoint price list for rate limits and costs
    api_response = api_instance.endpoint_weights()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InfoApi->endpoint_weights: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[EndpointWeights]**](EndpointWeights.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **web3_api_version**
> Web3version web3_api_version()

Returns the web3 api version

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.InfoApi(swagger_client.ApiClient(configuration))

try:
    # Returns the web3 api version
    api_response = api_instance.web3_api_version()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InfoApi->web3_api_version: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Web3version**](Web3version.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

