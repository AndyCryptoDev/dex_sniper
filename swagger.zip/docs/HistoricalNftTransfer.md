# HistoricalNftTransfer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_hash** | **str** | The transaction hash | 
**address** | **str** | The address of the token | 
**block_timestamp** | **str** | The block timestamp | 
**block_number** | **str** | The block number | 
**block_hash** | **str** | The block hash | 
**to_address** | **str** | The recipient | 
**from_address** | **str** | The sender | 
**token_ids** | **list[str]** | The token ids of the tokens that were transfered | 
**amounts** | **list[str]** | The amounts that were transfered | 
**contract_type** | **str** | They contract type of the transfer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

