# Erc20Price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**native_price** | [**NativeErc20Price**](NativeErc20Price.md) |  | [optional] 
**usd_price** | **float** | The price in USD for the token | 
**exchange_address** | **str** | The address of the exchange used to calculate the price | [optional] 
**exchange_name** | **str** | The name of the exchange used for calculating the price | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

