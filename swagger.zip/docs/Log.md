# Log

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_index** | **str** |  | 
**transaction_hash** | **str** | The hash of the transaction | 
**transaction_index** | **str** |  | 
**address** | **str** | The address of the contract | 
**data** | **str** | The data of the log | 
**topic0** | **str** |  | 
**topic1** | **str** |  | [optional] 
**topic2** | **str** |  | [optional] 
**topic3** | **str** |  | [optional] 
**block_timestamp** | **str** | The timestamp of the block | 
**block_number** | **str** | The block number | 
**block_hash** | **str** | The hash of the block | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

