# NftMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the contract of the NFT | 
**token_id** | **str** | The token id of the NFT | 
**contract_type** | **str** | The type of NFT contract standard | 
**token_uri** | **str** | The uri to the metadata of the token | 
**metadata** | **str** | The metadata of the token | 
**synced_at** | **str** | when the metadata was last updated | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

