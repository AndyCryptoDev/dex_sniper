# EndpointWeights

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint** | **str** | endpoint | 
**path** | **str** | The path to the endpoint | 
**rate_limit_weight** | **str** | The number of hits the requests counts for ratelimiting | 
**price** | **str** | The number of hits the requests counts for billing | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

