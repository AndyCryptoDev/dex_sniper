# swagger_client.AccountApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_native_balance**](AccountApi.md#get_native_balance) | **GET** /{address}/balance | Gets native balance for a specific address.
[**get_nf_ts**](AccountApi.md#get_nf_ts) | **GET** /{address}/nft | Gets the NFTs owned by a given address
[**get_nf_ts_for_contract**](AccountApi.md#get_nf_ts_for_contract) | **GET** /{address}/nft/{token_address} | Gets the NFTs owned by a given address
[**get_nft_transfers**](AccountApi.md#get_nft_transfers) | **GET** /{address}/nft/transfers | Gets NFT transfers to and from a given address
[**get_token_balances**](AccountApi.md#get_token_balances) | **GET** /{address}/erc20 | Gets token balances for a specific address.
[**get_token_transfers**](AccountApi.md#get_token_transfers) | **GET** /{address}/erc20/transfers | Gets erc 20 token transactions
[**get_transactions**](AccountApi.md#get_transactions) | **GET** /{address} | Gets native transactions

# **get_native_balance**
> NativeBalance get_native_balance(address, chain=chain, provider_url=provider_url, to_block=to_block)

Gets native balance for a specific address.

Gets native balance for a specific address

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address for which the native balance will be checked
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
to_block = 1.2 # float | The block number on which the balances should be checked (optional)

try:
    # Gets native balance for a specific address.
    api_response = api_instance.get_native_balance(address, chain=chain, provider_url=provider_url, to_block=to_block)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_native_balance: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address for which the native balance will be checked | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **to_block** | **float**| The block number on which the balances should be checked | [optional] 

### Return type

[**NativeBalance**](NativeBalance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nf_ts**
> NftOwnerCollection get_nf_ts(address, chain=chain, format=format, limit=limit, token_addresses=token_addresses, cursor=cursor)

Gets the NFTs owned by a given address

Gets NFTs owned by the given address * The response will include status [SYNCED/SYNCING] based on the contracts being indexed. * Use the token_address param to get results for a specific contract only * Note results will include all indexed NFTs * Any request which includes the token_address param will start the indexing process for that NFT collection the very first time it is requested 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The owner of a given token
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
limit = 56 # int | limit (optional)
token_addresses = ['token_addresses_example'] # list[str] | The addresses to get balances for (Optional) (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets the NFTs owned by a given address
    api_response = api_instance.get_nf_ts(address, chain=chain, format=format, limit=limit, token_addresses=token_addresses, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nf_ts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The owner of a given token | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **limit** | **int**| limit | [optional] 
 **token_addresses** | [**list[str]**](str.md)| The addresses to get balances for (Optional) | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nf_ts_for_contract**
> NftOwnerCollection get_nf_ts_for_contract(address, token_address, chain=chain, format=format, offset=offset, limit=limit)

Gets the NFTs owned by a given address

Gets NFTs owned by the given address * Use the token_address param to get results for a specific contract only * Note results will include all indexed NFTs * Any request which includes the token_address param will start the indexing process for that NFT collection the very first time it is requested 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The owner of a given token
token_address = 'token_address_example' # str | Address of the contract
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets the NFTs owned by a given address
    api_response = api_instance.get_nf_ts_for_contract(address, token_address, chain=chain, format=format, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nf_ts_for_contract: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The owner of a given token | 
 **token_address** | **str**| Address of the contract | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**NftOwnerCollection**](NftOwnerCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_transfers**
> NftTransferCollection get_nft_transfers(address, chain=chain, format=format, direction=direction, limit=limit, cursor=cursor)

Gets NFT transfers to and from a given address

Gets the transfers of the tokens matching the given parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The sender or recepient of the transfer
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
format = 'decimal' # str | The format of the token id (optional) (default to decimal)
direction = 'both' # str | The transfer direction (optional) (default to both)
limit = 56 # int | limit (optional)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets NFT transfers to and from a given address
    api_response = api_instance.get_nft_transfers(address, chain=chain, format=format, direction=direction, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_nft_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The sender or recepient of the transfer | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **format** | **str**| The format of the token id | [optional] [default to decimal]
 **direction** | **str**| The transfer direction | [optional] [default to both]
 **limit** | **int**| limit | [optional] 
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_balances**
> list[Erc20TokenBalance] get_token_balances(address, chain=chain, subdomain=subdomain, to_block=to_block, token_addresses=token_addresses)

Gets token balances for a specific address.

Gets token balances for a specific address

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address for which token balances will be checked
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
to_block = 1.2 # float | The block number on which the balances should be checked (optional)
token_addresses = ['token_addresses_example'] # list[str] | The addresses to get balances for (Optional) (optional)

try:
    # Gets token balances for a specific address.
    api_response = api_instance.get_token_balances(address, chain=chain, subdomain=subdomain, to_block=to_block, token_addresses=token_addresses)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_token_balances: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address for which token balances will be checked | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **to_block** | **float**| The block number on which the balances should be checked | [optional] 
 **token_addresses** | [**list[str]**](str.md)| The addresses to get balances for (Optional) | [optional] 

### Return type

[**list[Erc20TokenBalance]**](Erc20TokenBalance.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_transfers**
> Erc20TransactionCollection get_token_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)

Gets erc 20 token transactions

Gets ERC20 token transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
from_block = 56 # int | The minimum block number from where to get the transactions * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to get the transactions. * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to get the transactions (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get the transactions to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets erc 20 token transactions
    api_response = api_instance.get_token_transfers(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_token_transfers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **from_block** | **int**| The minimum block number from where to get the transactions * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to get the transactions. * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to get the transactions (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get the transactions to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**Erc20TransactionCollection**](Erc20TransactionCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_transactions**
> TransactionCollection get_transactions(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)

Gets native transactions

Gets native transactions in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.AccountApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
from_block = 56 # int | The minimum block number from where to get the transactions * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to get the transactions. * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to get the transactions (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get the transactions to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets native transactions
    api_response = api_instance.get_transactions(address, chain=chain, subdomain=subdomain, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AccountApi->get_transactions: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **from_block** | **int**| The minimum block number from where to get the transactions * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to get the transactions. * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to get the transactions (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get the transactions to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**TransactionCollection**](TransactionCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

