# Trade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_hash** | **str** | The transaction hash | 
**transaction_index** | **str** | The transaction index | 
**token_ids** | **list** | The token id(s) traded | 
**seller_address** | **str** | The address that sold the NFT | 
**buyer_address** | **str** | The address that bought the NFT | 
**marketplace_address** | **str** | The address of the contract that traded the NFT | 
**price** | **str** | The value that was sent in the transaction (ETH/BNB/etc..) | 
**block_timestamp** | **str** | The block timestamp | 
**block_number** | **str** | The blocknumber of the transaction | 
**block_hash** | **str** | The block hash | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

