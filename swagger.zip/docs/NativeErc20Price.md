# NativeErc20Price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | The native price of the token | 
**decimals** | **int** | The number of decimals of the token | 
**name** | **str** | The Name of the token | 
**symbol** | **str** | The Symbol of the token | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

