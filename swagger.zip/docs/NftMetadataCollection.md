# NftMetadataCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** | The total number of matches for this query | [optional] 
**page** | **int** | The page of the current result | [optional] 
**page_size** | **int** | The number of results per page | [optional] 
**result** | [**list[NftMetadata]**](NftMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

