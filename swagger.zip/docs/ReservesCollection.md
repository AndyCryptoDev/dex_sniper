# ReservesCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reserve0** | **str** | reserve0 | 
**reserve1** | **str** | reserve1 | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

