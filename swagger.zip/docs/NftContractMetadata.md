# NftContractMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token_address** | **str** | The address of the token contract | 
**name** | **str** | The name of the token Contract | 
**synced_at** | **str** | Timestamp of when the contract was last synced with the node | [optional] 
**symbol** | **str** | The symbol of the NFT contract | 
**contract_type** | **str** | The type of NFT contract | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

