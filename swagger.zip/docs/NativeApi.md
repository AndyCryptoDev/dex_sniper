# swagger_client.NativeApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_block**](NativeApi.md#get_block) | **GET** /block/{block_number_or_hash} | Gets block contents by block hash
[**get_contract_events**](NativeApi.md#get_contract_events) | **POST** /{address}/events | Gets events by topic
[**get_date_to_block**](NativeApi.md#get_date_to_block) | **GET** /dateToBlock | Gets the closest block of the provided date
[**get_logs_by_address**](NativeApi.md#get_logs_by_address) | **GET** /{address}/logs | Gets address logs
[**get_nft_transfers_by_block**](NativeApi.md#get_nft_transfers_by_block) | **GET** /block/{block_number_or_hash}/nft/transfers | Gets NFT transfers by block number or block hash
[**get_transaction**](NativeApi.md#get_transaction) | **GET** /transaction/{transaction_hash} | Get transaction details by transaction hash
[**run_contract_function**](NativeApi.md#run_contract_function) | **POST** /{address}/function | Runs a function of a contract abi

# **get_block**
> Block get_block(block_number_or_hash, chain=chain, subdomain=subdomain)

Gets block contents by block hash

Gets the contents of a block by block hash

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
block_number_or_hash = 'block_number_or_hash_example' # str | The block hash or block number
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)

try:
    # Gets block contents by block hash
    api_response = api_instance.get_block(block_number_or_hash, chain=chain, subdomain=subdomain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_block: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **block_number_or_hash** | **str**| The block hash or block number | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 

### Return type

[**Block**](Block.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_contract_events**
> list[LogEvent] get_contract_events(topic, address, body=body, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)

Gets events by topic

Gets events in descending order based on block number

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
topic = 'topic_example' # str | The topic of the event
address = 'address_example' # str | address
body = NULL # object | ABI of the specific event (optional)
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)
from_block = 56 # int | The minimum block number from where to get the logs * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_block = 56 # int | The maximum block number from where to get the logs. * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
from_date = 'from_date_example' # str | The date from where to get the logs (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used.  (optional)
to_date = 'to_date_example' # str | Get the logs to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used.  (optional)
offset = 56 # int | offset (optional)
limit = 56 # int | limit (optional)

try:
    # Gets events by topic
    api_response = api_instance.get_contract_events(topic, address, body=body, chain=chain, subdomain=subdomain, provider_url=provider_url, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_contract_events: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **topic** | **str**| The topic of the event | 
 **address** | **str**| address | 
 **body** | [**object**](object.md)| ABI of the specific event | [optional] 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 
 **from_block** | **int**| The minimum block number from where to get the logs * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_block** | **int**| The maximum block number from where to get the logs. * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **from_date** | **str**| The date from where to get the logs (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used.  | [optional] 
 **to_date** | **str**| Get the logs to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used.  | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] 

### Return type

[**list[LogEvent]**](LogEvent.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_date_to_block**
> BlockDate get_date_to_block(_date, chain=chain, provider_url=provider_url)

Gets the closest block of the provided date

Gets the closest block of the provided date

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
_date = '_date_example' # str | Unix date in miliseconds or a datestring (any format that is accepted by momentjs)
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Gets the closest block of the provided date
    api_response = api_instance.get_date_to_block(_date, chain=chain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_date_to_block: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_date** | **str**| Unix date in miliseconds or a datestring (any format that is accepted by momentjs) | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

[**BlockDate**](BlockDate.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_logs_by_address**
> LogEventByAddress get_logs_by_address(address, chain=chain, subdomain=subdomain, block_number=block_number, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, topic0=topic0, topic1=topic1, topic2=topic2, topic3=topic3)

Gets address logs

Gets the logs from an address

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
block_number = 'block_number_example' # str | The block number * Provide the param 'block_numer' or ('from_block' and / or 'to_block') * If 'block_numer' is provided in conbinaison with 'from_block' and / or 'to_block', 'block_number' will will be used  (optional)
from_block = 'from_block_example' # str | The minimum block number from where to get the logs * Provide the param 'block_numer' or ('from_block' and / or 'to_block') * If 'block_numer' is provided in conbinaison with 'from_block' and / or 'to_block', 'block_number' will will be used  (optional)
to_block = 'to_block_example' # str | The maximum block number from where to get the logs * Provide the param 'block_numer' or ('from_block' and / or 'to_block') * If 'block_numer' is provided in conbinaison with 'from_block' and / or 'to_block', 'block_number' will will be used  (optional)
from_date = 'from_date_example' # str | The date from where to get the logs (any format that is accepted by momentjs) * Provide the param 'from_block' or 'from_date' * If 'from_date' and 'from_block' are provided, 'from_block' will be used. * If 'from_date' and the block params are provided, the block params will be used. Please refer to the blocks params sections (block_number,from_block and to_block) on how to use them  (optional)
to_date = 'to_date_example' # str | Get the logs to this date (any format that is accepted by momentjs) * Provide the param 'to_block' or 'to_date' * If 'to_date' and 'to_block' are provided, 'to_block' will be used. * If 'to_date' and the block params are provided, the block params will be used. Please refer to the blocks params sections (block_number,from_block and to_block) on how to use them  (optional)
topic0 = 'topic0_example' # str | topic0 (optional)
topic1 = 'topic1_example' # str | topic1 (optional)
topic2 = 'topic2_example' # str | topic2 (optional)
topic3 = 'topic3_example' # str | topic3 (optional)

try:
    # Gets address logs
    api_response = api_instance.get_logs_by_address(address, chain=chain, subdomain=subdomain, block_number=block_number, from_block=from_block, to_block=to_block, from_date=from_date, to_date=to_date, topic0=topic0, topic1=topic1, topic2=topic2, topic3=topic3)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_logs_by_address: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **block_number** | **str**| The block number * Provide the param &#x27;block_numer&#x27; or (&#x27;from_block&#x27; and / or &#x27;to_block&#x27;) * If &#x27;block_numer&#x27; is provided in conbinaison with &#x27;from_block&#x27; and / or &#x27;to_block&#x27;, &#x27;block_number&#x27; will will be used  | [optional] 
 **from_block** | **str**| The minimum block number from where to get the logs * Provide the param &#x27;block_numer&#x27; or (&#x27;from_block&#x27; and / or &#x27;to_block&#x27;) * If &#x27;block_numer&#x27; is provided in conbinaison with &#x27;from_block&#x27; and / or &#x27;to_block&#x27;, &#x27;block_number&#x27; will will be used  | [optional] 
 **to_block** | **str**| The maximum block number from where to get the logs * Provide the param &#x27;block_numer&#x27; or (&#x27;from_block&#x27; and / or &#x27;to_block&#x27;) * If &#x27;block_numer&#x27; is provided in conbinaison with &#x27;from_block&#x27; and / or &#x27;to_block&#x27;, &#x27;block_number&#x27; will will be used  | [optional] 
 **from_date** | **str**| The date from where to get the logs (any format that is accepted by momentjs) * Provide the param &#x27;from_block&#x27; or &#x27;from_date&#x27; * If &#x27;from_date&#x27; and &#x27;from_block&#x27; are provided, &#x27;from_block&#x27; will be used. * If &#x27;from_date&#x27; and the block params are provided, the block params will be used. Please refer to the blocks params sections (block_number,from_block and to_block) on how to use them  | [optional] 
 **to_date** | **str**| Get the logs to this date (any format that is accepted by momentjs) * Provide the param &#x27;to_block&#x27; or &#x27;to_date&#x27; * If &#x27;to_date&#x27; and &#x27;to_block&#x27; are provided, &#x27;to_block&#x27; will be used. * If &#x27;to_date&#x27; and the block params are provided, the block params will be used. Please refer to the blocks params sections (block_number,from_block and to_block) on how to use them  | [optional] 
 **topic0** | **str**| topic0 | [optional] 
 **topic1** | **str**| topic1 | [optional] 
 **topic2** | **str**| topic2 | [optional] 
 **topic3** | **str**| topic3 | [optional] 

### Return type

[**LogEventByAddress**](LogEventByAddress.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nft_transfers_by_block**
> NftTransferCollection get_nft_transfers_by_block(block_number_or_hash, chain=chain, subdomain=subdomain, offset=offset, limit=limit, cursor=cursor)

Gets NFT transfers by block number or block hash

Gets NFT transfers by block number or block hash

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
block_number_or_hash = 'block_number_or_hash_example' # str | The block hash or block number
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
offset = 56 # int | offset (optional)
limit = 500 # int | limit (optional) (default to 500)
cursor = 'cursor_example' # str | The cursor returned in the last response (for getting the next page)  (optional)

try:
    # Gets NFT transfers by block number or block hash
    api_response = api_instance.get_nft_transfers_by_block(block_number_or_hash, chain=chain, subdomain=subdomain, offset=offset, limit=limit, cursor=cursor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_nft_transfers_by_block: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **block_number_or_hash** | **str**| The block hash or block number | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **offset** | **int**| offset | [optional] 
 **limit** | **int**| limit | [optional] [default to 500]
 **cursor** | **str**| The cursor returned in the last response (for getting the next page)  | [optional] 

### Return type

[**NftTransferCollection**](NftTransferCollection.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_transaction**
> BlockTransaction get_transaction(transaction_hash, chain=chain, subdomain=subdomain)

Get transaction details by transaction hash

Gets the contents of a block transaction by hash

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
transaction_hash = 'transaction_hash_example' # str | The transaction hash
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)

try:
    # Get transaction details by transaction hash
    api_response = api_instance.get_transaction(transaction_hash, chain=chain, subdomain=subdomain)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->get_transaction: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **transaction_hash** | **str**| The transaction hash | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 

### Return type

[**BlockTransaction**](BlockTransaction.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **run_contract_function**
> str run_contract_function(body, function_name, address, chain=chain, subdomain=subdomain, provider_url=provider_url)

Runs a function of a contract abi

Runs a given function of a contract abi and returns readonly data

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.NativeApi(swagger_client.ApiClient(configuration))
body = swagger_client.RunContractDto() # RunContractDto | Body
function_name = 'function_name_example' # str | function_name
address = 'address_example' # str | address
chain = swagger_client.ChainList() # ChainList | The chain to query (optional)
subdomain = 'subdomain_example' # str | The subdomain of the moralis server to use (Only use when selecting local devchain as chain) (optional)
provider_url = 'provider_url_example' # str | web3 provider url to user when using local dev chain (optional)

try:
    # Runs a function of a contract abi
    api_response = api_instance.run_contract_function(body, function_name, address, chain=chain, subdomain=subdomain, provider_url=provider_url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NativeApi->run_contract_function: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RunContractDto**](RunContractDto.md)| Body | 
 **function_name** | **str**| function_name | 
 **address** | **str**| address | 
 **chain** | [**ChainList**](.md)| The chain to query | [optional] 
 **subdomain** | **str**| The subdomain of the moralis server to use (Only use when selecting local devchain as chain) | [optional] 
 **provider_url** | **str**| web3 provider url to user when using local dev chain | [optional] 

### Return type

**str**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

