# swagger_client.ResolveApi

All URIs are relative to *https://deep-index.moralis.io/api/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**resolve_address**](ResolveApi.md#resolve_address) | **GET** /resolve/{address}/reverse | Return the ENS domain when available (Only for ETH)
[**resolve_domain**](ResolveApi.md#resolve_domain) | **GET** /resolve/{domain} | Resolves an Unstoppable domain and returns the address

# **resolve_address**
> Ens resolve_address(address)

Return the ENS domain when available (Only for ETH)

Resolves an ETH address and find the ENS name 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ResolveApi(swagger_client.ApiClient(configuration))
address = 'address_example' # str | The address to be resolved

try:
    # Return the ENS domain when available (Only for ETH)
    api_response = api_instance.resolve_address(address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResolveApi->resolve_address: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **address** | **str**| The address to be resolved | 

### Return type

[**Ens**](Ens.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **resolve_domain**
> Resolve resolve_domain(domain, currency=currency)

Resolves an Unstoppable domain and returns the address

Resolves an Unstoppable domain and returns the address 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['X-API-Key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['X-API-Key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ResolveApi(swagger_client.ApiClient(configuration))
domain = 'domain_example' # str | Domain to be resolved
currency = 'eth' # str | The currency to query (optional) (default to eth)

try:
    # Resolves an Unstoppable domain and returns the address
    api_response = api_instance.resolve_domain(domain, currency=currency)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResolveApi->resolve_domain: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain to be resolved | 
 **currency** | **str**| The currency to query | [optional] [default to eth]

### Return type

[**Resolve**](Resolve.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

